        Index Version 2.0.4.5 by Larry J. McDavid
-----------------------------------------------------------------------
Index is  designed to help you organize all your
 notes, phone numbers, addresses, and other 
 things that you want to remember into one simple
 program that is easy to use. 

Index Includes the following functions:
The Tray Icon:
 When you start the program, a small icon will appear
 in the System Tray next to the clock and also on the
 Desktop. Right click for the context menu or double
 click to open the main Index Program.

The Index Program:
 Index is a simple program designed to save your
 memos and  notes and organize them in a manner
 similar to a tabbed index  card file. Choose the appropriate
 tab for your notes. You may  also add and remove  tabs
. All the functions are also available from this part of the program.

Editor:
Editor is a text editor similar to Notepad

Quick Notes:
Quick Notes is an easy way to quickly write yourself a note and
 if you wish, to print it out. The Quick Notes program operates
 similar to the Index program. Just type your notes in the text box
 and close the program.Right click in the text box to open the Menu.
 The Quick Notes Window can be resized to any dimensions that
 you wish. 

 Reminder:
  Reminder is a simple program designed to help
you remember Dates, Appointments, and other things.
There are  four types of Reminder to choose from:
 Reminder, the most flexible, allows you to choose the Date and Time of your 
Reminders and also an Interval between Reminders. 

Weekly Reminder, When you wish to be reminded on a certain day of the
 week instead of a particular date, you use the Weekly Reminder function.
 
Daily Reminder, When you wish to be reminded every day  instead of a
 particular date, you use the Daily Reminder function.
 
Monthly Reminder, When you wish to be reminded on a certain day of the
 Month instead of a particular date, you use the Monthly  Reminder function. 
------------------------------------------------------------------------------------
Changes:
Index and Quick Notes now have the ability to launch URL's and your E-Mail program
by clicking on the links.
ON the first bootup of the day Reminder will now show Reminders on the designated date if the designated time occured while the computer was down.
Reminder Bug fixes
In the Monthly Reminder section, the Alarm Sound button now functions correctly.
Various bug fixes
------------------------------------------------------------------------------------ 
Requirements: Index requires comctl32.dll version 4.70 or above.This file will
probably be on your system. The 4.00 versions of Shell32.dll and Comctl32.dll are found on the original versions of Windows 95 and Windows NT 4. New versions of Commctl.dll were shipped with all Internet Explorer releases. 
If this version is not on your system, you can download it here.
http://download.microsoft.com/download/platformsdk/Comctl32/5.80.2614.3600/W9XNT4/EN-US/50comupd.exe

------------------------------------------------------------------------------------
Install Instructions:  unzip the archive ndex2045.zip and run Setup.exe
Be sure to close any running instances of Index before Running Setup.
 If you are going to install a newer version of Index, it is not necessary to
uninstall the older version first.
----------------------------------------------------------------------------------
 Uninstalling Index
When you uninstall Index, all your Settings will be deleted.
Your Data files will not be deleted, it will be necessary for you to delete 
them manually if you wish to completely remove them from your system.

------------------------------------------------------------------------------------
 When you start the program, a small 
icon will appear in the System Tray next 
to the clock.Right click for the context menu or 
double click to run the main program.
-------------------------------------------------
 Index is freeware and may be freely distributed.
For support , bug reports, comments and suggestions
to improve this program send email to me:

Larry J. McDavid
lmcdavid@mounet.com

The latest version of Index will be found here
http://www.geocities.com/ljmcdavid/download/
******************************************************
Disclaimer
  Usage of this program is entirely at your own risk.
There are no warranties, either express or implied.
****************************************************** 


